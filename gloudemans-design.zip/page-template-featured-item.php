<div class="featured-item">
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<h1>Lorem ipsum dolor sit amet</h1>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
				<p>Quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
				<button class="btn btn-info">Read More</button>
				<button class="btn btn-primary">Buy Now</button>
			</div>
			<div class="col-md-6">
				<img src="http://lorempixel.com/700/300/city/6" alt="Lorem ipsum dolor" class="featured-item-image">
			</div>
		</div>
	</div>
</div>