;(function($) {
    $(function() {

        $('.color-taxonomy-input').wpColorPicker();

	});
})(jQuery);