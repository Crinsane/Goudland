<div class="featured-bullets">
	<div class="container">
		<div class="row">
			<div class="col-sm-3 featured-bullet">
				<div class="featured-bullet-icon center-block bg-info">
					<h2><i class="fa fa-area-chart"></i></h2>
				</div>
				<h5>Lorem ipsum dolor</h5>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt.</p>
				<p><a href="#" class="read-more">Read More &rarr;</a>
			</div>
			<div class="col-sm-3 featured-bullet">
				<div class="featured-bullet-icon center-block bg-info">
					<h2><i class="fa fa-university"></i></h2>
				</div>
				<h5>Eiusmod tempor incididunt</h5>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt.</p>
				<p><a href="#" class="read-more">Read More &rarr;</a>
			</div>
			<div class="col-sm-3 featured-bullet">
				<div class="featured-bullet-icon center-block bg-info">
					<h2><i class="fa fa-paper-plane"></i></h2>
				</div>
				<h5>Consectetur adipisicing elit</h5>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt.</p>
				<p><a href="#" class="read-more">Read More &rarr;</a>
			</div>
			<div class="col-sm-3 featured-bullet">
				<div class="featured-bullet-icon center-block bg-info">
					<h2><i class="fa fa-leaf"></i></h2>
				</div>
				<h5>Sed do eiusmod</h5>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt.</p>
				<p><a href="#" class="read-more">Read More &rarr;</a>
			</div>
		</div>
	</div>
</div>