;(function($) {
	$(function() {

        //$('.contact-form').on('submit', function(e) {
        //    e.preventDefault();
        //
        //    var form = $(this),
        //        formContent = form.serializeArray();
        //
        //    validateContent(formContent);
        //});
        //
        //function validateContent(content) {
        //    $.each(content, function(key, value) {
        //       console.log(key, value);
        //    });
        //}

        $('.continuous-carousel').cycle();

	})
})(jQuery);