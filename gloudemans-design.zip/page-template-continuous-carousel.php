<div class="continuous-carousel"
     data-cycle-fx="carousel"
     data-cycle-speed="5000"
     data-cycle-timeout="1"
     data-cycle-easing="linear"
	>
	<img src="http://lorempixel.com/125/125/business/1" alt="Lorem ipsum dolor">
	<img src="http://lorempixel.com/125/125/business/2" alt="Lorem ipsum dolor">
	<img src="http://lorempixel.com/125/125/business/3" alt="Lorem ipsum dolor">
	<img src="http://lorempixel.com/125/125/business/4" alt="Lorem ipsum dolor">
	<img src="http://lorempixel.com/125/125/business/5" alt="Lorem ipsum dolor">
	<img src="http://lorempixel.com/125/125/business/6" alt="Lorem ipsum dolor">
	<img src="http://lorempixel.com/125/125/business/7" alt="Lorem ipsum dolor">
	<img src="http://lorempixel.com/125/125/business/8" alt="Lorem ipsum dolor">
	<img src="http://lorempixel.com/125/125/business/9" alt="Lorem ipsum dolor">
	<img src="http://lorempixel.com/125/125/business/10" alt="Lorem ipsum dolor">
</div>