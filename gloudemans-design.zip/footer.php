	<?php get_template_part('footer', 'social-media');?>

	<?php get_template_part('footer', 'main');?>

	<?php get_template_part('footer', 'bottom');?>

	<?php wp_footer();?>
</body>
</html>


