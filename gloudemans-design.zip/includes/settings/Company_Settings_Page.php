<?php

class Company_Settings_Page {

	/**
	 * The main options from the database
	 *
	 * @var array
	 */
	protected $optionsMain;

	/**
	 * The social media options from the database
	 *
	 * @var array
	 */
	protected $optionsSocialMedia;

	/**
	 * Register the settings page and options
	 */
	public function __construct()
	{
		add_action('admin_menu', [$this, 'addSettingsPage']);
		add_action('admin_init', [$this, 'buildSettingsPage']);
	}

	/**
	 * Add the settings page
	 */
	public function addSettingsPage()
	{
		add_menu_page(
			'Bedrijfsgegevens',
			'Bedrijfsgegevens',
			'manage_options',
			'company-settings',
			[$this, 'displaySettingsPage']
		);
	}

	/**
	 * Display the settings page
	 */
	public function displaySettingsPage()
	{
		$this->optionsMain = get_option('options_main');
		$this->optionsSocialMedia = get_option('options_social_media');

//		$tab = $this->getTab();

		?>
			<div class="wrap">
				<h2>Bedrijfsgegevens</h2>
<!--				<h2 class="nav-tab-wrapper">-->
<!--					<a href="--><?php //menu_page_url('company-settings');?><!--&tab=main" class="nav-tab --><?php //echo $tab == 'main' ? 'nav-tab-active' : ''; ?><!--">Algemeen</a>-->
<!--					<a href="--><?php //menu_page_url('company-settings');?><!--&tab=social-media" class="nav-tab --><?php //echo $tab == 'social-media' ? 'nav-tab-active' : ''; ?><!--">Social Media</a>-->
<!--				</h2>-->

				<form method="post" action="options.php">

					<?php
						settings_fields('company_settings');
						do_settings_sections('options_main');
						do_settings_sections('options_social_media');
					?>

					<?php submit_button();?>
				</form>
			</div>
		<?php
	}

	/**
	 * Build the company settings page
	 */
	public function buildSettingsPage()
	{
		register_setting(
			'company_settings',
			'options_main',
			[$this, 'sanitize']
		);

		register_setting(
			'company_settings',
			'options_social_media',
			[$this, 'sanitize']
		);

		add_settings_section(
			'company_settings_main', // ID
			'Algemene instellingen', // Title
			[$this, 'printMainSectionInfo'], // Callback
			'options_main' // Page
		);

		add_settings_section(
			'company_settings_social_media', // ID
			'Social Media', // Title
			[$this, 'printSocialMediaSectionInfo'], // Callback
			'options_social_media' // Page
		);

		add_settings_field(
			'name', // ID
			'Naam', // Title
			[$this, 'nameField'], // Callback
			'options_main', // Page
			'company_settings_main' // Section
		);

		add_settings_field(
			'facebook', // ID
			'Facebook', // Title
			[$this, 'socialMediaField'], // Callback
			'options_social_media', // Page
			'company_settings_social_media', // Section
			['facebook']
		);

		add_settings_field(
			'twitter', // ID
			'Twitter', // Title
			[$this, 'socialMediaField'], // Callback
			'options_social_media', // Page
			'company_settings_social_media', // Section
			['twitter']
		);

		add_settings_field(
			'pinterest', // ID
			'Pinterest', // Title
			[$this, 'socialMediaField'], // Callback
			'options_social_media', // Page
			'company_settings_social_media', // Section
			['pinterest']
		);

		add_settings_field(
			'google', // ID
			'Google+', // Title
			[$this, 'socialMediaField'], // Callback
			'options_social_media', // Page
			'company_settings_social_media', // Section
			['google']
		);

		add_settings_field(
			'tumblr', // ID
			'Tumblr', // Title
			[$this, 'socialMediaField'], // Callback
			'options_social_media', // Page
			'company_settings_social_media', // Section
			['tumblr']
		);

		add_settings_field(
			'flickr', // ID
			'Flickr', // Title
			[$this, 'socialMediaField'], // Callback
			'options_social_media', // Page
			'company_settings_social_media', // Section
			['flickr']
		);

		add_settings_field(
			'instagram', // ID
			'Instagram', // Title
			[$this, 'socialMediaField'], // Callback
			'options_social_media', // Page
			'company_settings_social_media', // Section
			['instagram']
		);

		add_settings_field(
			'github', // ID
			'Github', // Title
			[$this, 'socialMediaField'], // Callback
			'options_social_media', // Page
			'company_settings_social_media', // Section
			['github']
		);

		add_settings_field(
			'bitbucket', // ID
			'Bitbucket', // Title
			[$this, 'socialMediaField'], // Callback
			'options_social_media', // Page
			'company_settings_social_media', // Section
			['bitbucket']
		);

		add_settings_field(
			'vimeo', // ID
			'Vimeo', // Title
			[$this, 'socialMediaField'], // Callback
			'options_social_media', // Page
			'company_settings_social_media', // Section
			['vimeo']
		);

		add_settings_field(
			'youtube', // ID
			'YouTube', // Title
			[$this, 'socialMediaField'], // Callback
			'options_social_media', // Page
			'company_settings_social_media', // Section
			['youtube']
		);
	}

	/**
	 * Sanitize the input from the form
	 *
	 * @param  array  $input
	 * @return array
	 */
	public function sanitize($input)
	{
		//

		return $input;
	}


	/**
	 * Print the main section info
	 */
	public function printMainSectionInfo()
	{
		echo 'Enter your main settings below:';
	}

	/**
	 * Print the social media section info
	 */
	public function printSocialMediaSectionInfo()
	{
		echo 'Enter your social media settings below:';
	}

	/**
	 *  Display the name field
	 */
	public function nameField()
	{
		$name = $this->optionsMain['name'];

		echo '<input type="text" id="name" name="options_main[name]" value="' . $name . '">';
	}

	/**
	 * Display the social media field
	 *
	 * @param  array $args
	 * @return string
	 */
	public function socialMediaField($args)
	{
		$type = $args[0];
		$option = isset($this->optionsSocialMedia[$type]) ? $this->optionsSocialMedia[$type] : '';

		echo '<input type="text" id="' . $type . '" name="options_social_media[' . $type . ']" value="' . $option . '">';
	}


	/**
	 * Get the settings type from the query string
	 *
	 * @return string
	 */
	protected function getTab()
	{
		if(isset($_GET['tab']))
			return $_GET['tab'];

		return 'main';
	}

}